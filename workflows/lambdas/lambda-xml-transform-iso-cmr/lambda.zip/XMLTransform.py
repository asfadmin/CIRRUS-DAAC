#!/usr/bin/env python

import time
import json
import os
import re
import sys

import boto3
import mimetypes
import lxml.etree as ET
from run_cumulus_task import run_cumulus_task

schemas = {
        "input": "schemas/input.json",
        "config": "schemas/config.json"
        # "output": "schemas/output.json"
}

s3 = boto3.resource('s3')


def TransformXml(vars, input_xml, out_bucket, out_key, is_lambda):

    # input_xml passed in is the full S3 URL to the iso xml read from CMA payload

    parser = ET.XMLParser(remove_blank_text=True)

    if is_lambda:

        # Read style sheet included in package. This XSL works for all ISOXML at NSIDC now
        xsl_filename = 'inputs/GranTransform.xsl'
        xml_output = out_key
        xml = ET.fromstring(input_xml)
        print('Transforming iso.xml to cmr.xml using style sheet:', xsl_filename)

    else:

        # Set hardcoded values for local files
        input_xml = 'inputs/input.xml'
        xml_output = 'outputs/output.xml'
        xsl_filename = 'inputs/GranTransform.xsl'
        print('Transforming iso.xml to cmr.xml using style sheet:(local)', xsl_filename)
        xml = ET.parse(input_xml, parser)

    # remove spaces when parsing so pretty print works

    xsl = ET.parse(xsl_filename, parser)

    # Create Transformation Def
    transform = ET.XSLT(xsl)

    # Transform Variables to XML
    newxml = transform(xml, granuleUR=ET.XSLT.strparam(vars['granuleUR']), insertTime=ET.XSLT.strparam(vars['insertTime']), updateTime=ET.XSLT.strparam(vars['updateTime']), URLs=ET.XSLT.strparam(vars['URLs']), datasetId=ET.XSLT.strparam(vars['datasetId']), granuleSize=ET.XSLT.strparam(str(vars['granuleSize'])))

    # This will need to be an S3 Object write and will need to be added to CMA payload
    if is_lambda:

        print('Lambda: write S3 object', xml_output)
        out_bucket.put_object(Key=xml_output, Body=ET.tostring(newxml, pretty_print=True))

    else:
        print('Local: writing', xml_output)
        newxml.write(xml_output, pretty_print=True)

# End TransformXml


def get_mime(file):

    filename = os.path.basename(file)
    mtype, _ = mimetypes.guess_type(filename, strict=False)

    return(str(mtype))

# End get_mime


def get_input_local():

    print('Local: read CMA input files')

    CMA_data = json.load(open('inputs/CMA_data.json'))

    is_lambda = False
    def_exclude = False
    mimeTypes = ""
    ret_files = []

    datasetId = CMA_data['output']['meta']['collection']['name']
    file_defs = {}
    file_defs = CMA_data['output']['meta']['collection']['files']

    if 'meta' in CMA_data['output']['meta']['collection'].keys():
        for key in CMA_data['output']['meta']['collection']['meta'].keys():
            print('Collection Meta Keys:', key)
            if key == 'bucketExcludes':
                def_exclude = True
            if key == 'mimeTypes':
                mimeTypes = CMA_data['output']['meta']['collection']['meta']['mimeTypes']
                print('Setting MIME Type from collection config')
            # override datasetId default collection name if set
            if key == 'datasetId':
                datasetId = CMA_data['output']['meta']['collection']['meta']['datasetId']

    if mimeTypes == "":
        print('No MIME Types defiined in collection, using mimetypes lib')

    # If bucket exclude is defined set it
    if def_exclude:
        excl_bucket = CMA_data['output']['meta']['collection']['meta']['bucketExcludes']
        print('Found Collection Defined Bucket Excludes')

    # Default exclude is buckets contiaining word 'private'
    else:
        excl_bucket = ['private']
        print('Setting Bucket Exclude to default, private')

    for granule in CMA_data['output']['payload']['granules']:

        print('Processing granule: ', granule['granuleId'])
        prep_task(granule, datasetId, file_defs, excl_bucket, mimeTypes, is_lambda)

    return ret_files


def get_input_lambda(event, context):

    print('Lambda: read CMA paylod')
    is_lambda = True
    def_exclude = False
    mimeTypes = ""
    ret_files = []
    ret_granules = []

    datasetId = event['config']['collection']['name']
    file_defs = {}
    file_defs = event['config']['collection']['files']

    if 'meta' in event['config']['collection'].keys():
        for key in event['config']['collection']['meta'].keys():
            if key == 'bucketExcludes':
                def_exclude = True
            if key == 'mimeTypes':
                mimeTypes = event['config']['collection']['meta']['mimeTypes']
                print('Setting MIME Type from collection config')
            # override datasetId default collection name if set
            if key == 'datasetId':
                datasetId = event['config']['collection']['meta']['datasetId']
                print('Setting DataSetId from collection config meta datasetId value')

    if mimeTypes == "":
        print('No MIME Types defiined in collection, using mimetypes lib')

    # If bucket exclude is defined set it
    if def_exclude:
        excl_bucket = event['config']['collection']['meta']['bucketExcludes']
        print('Found Collection Defined Bucket Excludes')

    # Default exclude is buckets contiaining word 'private'
    else:
        excl_bucket = ['private']
        print('Setting Bucket Exclude to default, private')

    for granule in event['input']['granules']:

        print('Processing granule: ', granule['granuleId'])
        ret_files = prep_task(granule, datasetId, file_defs, excl_bucket, mimeTypes, is_lambda)
        ret_granule = {"granuleId": granule['granuleId'], "dataType": granule['dataType'], "version": granule['version'], "files": ret_files}
        ret_granules.append(ret_granule)

    print('payload granules: ', ret_granules)

    return {"granules": ret_granules}

# End get_input


def prep_task(granule, datasetId, file_defs, excl_bucket, mimeTypes, is_lambda):

    vars = {}
    URLs = []
    ret_files = []
    gran_size = 0
    create_cmrfile = False

    vars['granuleUR'] = granule['granuleId']
    vars['datasetId'] = datasetId

    # Iterate through all Files in Granule from CMA Payload
    # Get file Extension and match for file time and mime type from Collection_json file
    # Get size of science files and total them, get timestamp from science file

    for file in granule['files']:

        # by default don't exclude any files
        exclude = False

        # return all files to add to granule payload
        ret_files.append(file)

        # Loop Excludes Containing BucketContains words from Collections Config, exclude if match
        for bucketStr in excl_bucket:

            if bucketStr in file['bucket']:
                print('Excluding file: ', file['name'])
                exclude = True

        if exclude is False:
            create_cmrfile = True
            print('Including file: ', file['name'])

            URL = (file['filename'])
            mimeMatch = False
            fdef = {}
            f_type = None

            for fdef in file_defs:

                f_type = None

                regex = re.compile(fdef.get('regex'))
                match = regex.match(file['name'])

                if match:
                    f_type = fdef['dataType']
                    break

            if mimeTypes == '':
                mimeType = get_mime(file['name'])

            else:
                for ext, mtype in mimeTypes.items():
                    if ext == file['name'].split('.')[-1]:
                        mimeType = mtype
                        mimeMatch = True
                        break
                        # print('Found matching mimeType definition in collection')

                if not mimeMatch:
                    mimeType = get_mime(file['name'])
                    # print('No matching mimeType definition in collection using mimetype mod')

            if f_type is None:
                print('Warning: Regex did not match any of the filenames:', file['name'])

            # URLs with FileTypes an MimeTypes are fed to XSL as one long string
            URLs.append(URL + ',' + f_type + ',' + mimeType)

            # Total Granule Size is Size of all Science Files. Use science file timestamp as insert time
            if f_type == 'SCIENCE':
                gran_size += file['size']
                epoch_insertTime = float(file['time'])/1000

            # Get bucket of input iso.xml to put cmr.xml in
            if f_type == 'METADATA':

                bname = file['bucket']
                out_bucket = s3.Bucket(bname)
                out_key = URL.replace('iso.xml', 'cmr.xml', 1).split('/', 3)[3]
                key = file['filename'].split('/', 3)[3]

                # Create CMR file object to add to granule return
                cmrfile = {"name": file['name'].replace('iso.xml', 'cmr.xml'), "bucket": bname, "url_path": file['url_path'], "type": file['type'], "filename": file['filename'].replace('iso.xml', 'cmr.xml'), "filepath": file['filepath'].replace('iso.xml', 'cmr.xml')}

                ret_files.append(cmrfile)

                if is_lambda:
                    key = file['filename'].split('/', 3)[3]
                    input_obj = s3.Object(file['bucket'], key)
                    input_xml = input_obj.get()['Body'].read()
                else:
                    input_xml = 'inputs/input.xml'
    if create_cmrfile is False:
        print('WARNING: All files are excluded based on bucketExclude: Exiting no cmrfile created ')
        return granule['files']
        sys.exit()
    vars['URLs'] = ';'.join(URLs)

    # Getting Insert Time (above) from Payload, may want to get Original S3 object time for H5 File
    # Setting Update Time to Insert Time, may want to get S3 last modified time for H5 Science File

    vars['insertTime'] = time.strftime('%Y-%m-%dT%H:%M:%S.%sZ', time.gmtime(epoch_insertTime))
    vars['updateTime'] = vars['insertTime']

    # convert to MB, Transform expects strings
    vars['granuleSize'] = str(gran_size/(1024*1024))

    TransformXml(vars, input_xml, out_bucket, out_key, is_lambda)

    return ret_files

# End get_input


def lambda_handler(event, context):
    return run_cumulus_task(get_input_lambda, event, context, schemas)

# End lambda_handler


if __name__ == '__main__':
    get_input_local()

# End main
