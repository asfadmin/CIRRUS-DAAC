from .XMLTransform import lambda_handler  # noqa
